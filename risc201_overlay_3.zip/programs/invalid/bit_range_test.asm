tog r1, r2, #32
