addd r1, r2, r3
