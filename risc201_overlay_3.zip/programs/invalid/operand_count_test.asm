pcnt r1
